#ifndef READ_H
#define READ_H

#include <vector>

class Read {
public:
  static float** readData();
};

#endif
